﻿using System;
using ClassLibrary1;


class method
{
    static void Main()
    {
        Manager obj2 = new Manager();
        //Console.WriteLine("Enter Employee Salary:");
        MarketingExecutive ob = new MarketingExecutive();
        Console.WriteLine("enter no.of employee");
        int size = Convert.ToInt32(Console.ReadLine());
        Employee[] obj1 = new Employee[size];
        Employee obj = new Employee();
        try
        {
            double Salary = double.Parse(Console.ReadLine());
            obj2.setSalary(Salary);
            obj2.getSalary();
            obj2.setPetrol_Allowance();
            obj2.getPetrol_Allowance();
            obj2.setFood_Allowance();
            obj2.getFood_Allowance();
            obj2.setOther_Allowances();
            obj2.getOther_Allowances();
            obj2.setgs();
            obj2.getgs();
            Console.WriteLine("----------Accepting Employee Details----------");

            for (int i = 0; i < obj1.Length; i++)
            {
                Console.WriteLine("Enter Employee Number:");
                int no = int.Parse(Console.ReadLine());
                obj.setempno(no);

                Console.WriteLine("Enter Employee Name:");
                string name = Console.ReadLine();
                obj.setempname(name);

                Console.WriteLine("Enter Employee Salary:");
                double salary = double.Parse(Console.ReadLine());
                obj.setEmpSalary(salary);
                obj.sethra();
                obj.setta();
                obj.setda();
                obj.setgs();
                obj.calculatesalary();
                //create a list
                List<string> list = new List<string>();
                //add elements in the list
                list.Add(name);//here name is string which used to enter the employeename in the main method 

                Console.WriteLine("enter the employee name to search");
                string target = Console.ReadLine();

                bool isexist = list.Contains(target);
                if (isexist)
                {
                    Console.WriteLine("Element found in the list");
                }
                else
                {
                    Console.WriteLine("Element not found in the given list");
                }

            }
            Console.WriteLine("----------displaying Employee Details----------");
            for (int i = 0; i < obj1.Length; i++)
            {
                obj.getEmpNo();
                obj.getEmpName();
                obj.getEmpSalary();
                obj.getgs();
                obj.getcs();
            }
        }
        //catch (Exception ex)
        //{
        //    Console.WriteLine(ex.GetType().Name);
        //}




        catch (Exception e)
        {
            Console.WriteLine(e);
        }
        ob.settour();
        ob.setkm();
        ob.gett();
        ob.getkm();
        ob.setgs();
        ob.gettel();
    }
}
    
       
  
            