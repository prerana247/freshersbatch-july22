﻿using System;
using avg;

namespace swappingg

{
    internal class Program1

    {
        static void Main(string[] args)
        {

            int n1, n2;
            Console.Write("\n\nFunction : To swap the values of two integer numbers :\n");
            Console.Write("----------------------------------------------------------\n");
            Console.Write("Enter a number: ");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter another number: ");
            n2 = Convert.ToInt32(Console.ReadLine());
            swapfun.interchange(ref n1, ref n2);
            Console.WriteLine("Now the 1st number is : {0} , and the 2nd number is : {1}", n1, n2);

        }
    }
}