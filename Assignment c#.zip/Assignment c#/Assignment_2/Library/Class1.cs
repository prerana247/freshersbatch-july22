﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib
{
    public class NewEmp
    {
        int EmpNo;
        string EmpName;
        double Salary;
        double GrossSalary;

        public void setempno(int empno)
        {
            this.EmpNo = empno;
        }
        public void getEmpNo()
        {
            Console.WriteLine("Employee Number is: " + this.EmpNo);
        }

        public void setempname(string empname)
        {
            this.EmpName = empname;
        }
        public void getEmpName()
        {
            Console.WriteLine("Employee Name is: " + this.EmpName);
        }

        public void setEmpSalary(double Sal)
        {
            this.Salary = Sal;
        }
        public void getEmpSalary()
        {
            Console.WriteLine("Employee Salary is: " + this.Salary);
        }
        public void getgs()
        {
            Console.WriteLine("Employee GrossSalary is :" + this.GrossSalary);
        }
    }
}