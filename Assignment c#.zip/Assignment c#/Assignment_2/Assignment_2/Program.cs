﻿using System;
using LitwareLib;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;


namespace CSharp_Assignment2
{
    class Program
    {
        public static void Main()
        {

            try
            {
                Console.WriteLine("enter no.of employee");
                int size = Convert.ToInt32(Console.ReadLine());
                Employee[] obj1 = new Employee[size];
                Employee obj = new Employee();
                Console.WriteLine("----------Accepting Employee Details----------");

                for (int i = 0; i < obj1.Length; i++)
                {
                    Console.WriteLine("Enter Employee Number:");
                    int no = int.Parse(Console.ReadLine());
                    obj.setempno(no);

                    Console.WriteLine("Enter Employee Name:");
                    string name = Console.ReadLine();
                    obj.setempname(name);

                    Console.WriteLine("Enter Employee Salary:");
                    double salary = double.Parse(Console.ReadLine());
                    obj.setEmpSalary(salary);
                    obj.sethra();
                    obj.setta();
                    obj.setda();
                    obj.setgs();
                    obj.calculatesalary();
                }
                Console.WriteLine("----------displaying Employee Details----------");
                for (int i = 0; i < obj1.Length; i++)
                {
                    obj.getEmpNo();
                    obj.getEmpName();
                    obj.getEmpSalary();
                    obj.getgs();
                    obj.getcs();
                }
                FileStream f = new FileStream(@"C:\Users\HP\Desktop\Assignment c#\Assignment_7\Assin7_2\Assin7_2\empdetails.txt", FileMode.Open, FileAccess.Write);
                BinaryFormatter b = new BinaryFormatter();
                b.Serialize(f, obj1);
                f.Close();


                FileStream fr = new FileStream(@"C:\Users\HP\Desktop\Assignment c#\Assignment_7\Assin7_2\Assin7_2\empdetails.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter br = new BinaryFormatter();
                br.Deserialize(fr);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType().Name);
               
            }

            
        }
    }
}