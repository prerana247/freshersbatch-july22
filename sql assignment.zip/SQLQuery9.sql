Use Assignment
go
CREATE TABLE Supplier
(
ID int not null primary key,
CompanyName nvarchar(40) ,
ContactName nvarchar(40) ,
ContactTitle nvarchar(40) ,
City nvarchar (40) ,
Country nvarchar (40) ,
Phone nvarchar(20) ,
FaxNumber nvarchar(30) 
)
select * from Supplier
insert into Supplier (Id,CompanyName,ContactName,ContactTitle,City,Country,Phone,FaxNumber) values (1,'Grandma Kellys Homestead','chandrasekar',NULL,'Oslo','USA','(0)1-953530','(0)1-953555')
insert into Supplier (Id,CompanyName,ContactName,ContactTitle,City,Country,Phone,FaxNumber) values (2,'Pavlova, Ltd.','Ian Devling',NULL,'Sydney','Australia','(0)1-953440','(0)1-953666')
insert into Supplier (Id,CompanyName,ContactName,ContactTitle,City,Country,Phone,FaxNumber) values (3,'Exotic Liquids','Charlotte Cooper',NULL,'Iasi','UK','(0)1-953460','(0)1-953656')
insert into Supplier (Id,CompanyName,ContactName,ContactTitle,City,Country,Phone,FaxNumber) values (4,'Wipro Ltd.','Ian Devling',NULL,'Sydney','Australia','(0)1-953456','(0)1-953688')

SELECT * 
FROM   Supplier
WHERE  companyname = 'Exotic Liquids'

SELECT SUBSTRING([CompanyName],1,1) AS [FIRST-LETTER-OF-COMPANY],[CompanyName] FROM Supplier