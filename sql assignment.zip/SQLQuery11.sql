USE ASSIGNMENT
GO
CREATE TABLE STOCK
(
ID int not null,
productname nvarchar (30),
Unitonorder int , 
Unitinstock int ,
Stockstatus bit 

)
select*from stock
insert into stock (ID,productname,Unitonorder,Unitinstock,Stockstatus) values (1,'coffee',39,'30','0')
insert into stock (ID,productname,Unitonorder,Unitinstock,Stockstatus) values (2,'seafood',40,'3','1')
insert into stock (ID,productname,Unitonorder,Unitinstock,Stockstatus) values (3,'chai',20,'0','1 ')
insert into stock (ID,productname,Unitonorder,Unitinstock,Stockstatus) values (4,'chocolate',90,'30','0')
insert into stock (ID,productname,Unitonorder,Unitinstock,Stockstatus) values (5,'nutella',50,'20','1')
select * from stock where Stockstatus = 0


select productname from stock where Unitinstock < Unitonorder