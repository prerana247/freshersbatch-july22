use[Assignment]
go
create table Product
(
Id int not null primary key,
ProductName nvarchar(50),
UnitPrice decimal(12,2),
Package nvarchar(30),
IsDiscontinued bit
)
select * from Product
insert into Product (Id,ProductName,UnitPrice,Package,IsDiscontinued) values (1,'coffee',535.82,'16 - 500 g tins',1)
insert into Product (Id,ProductName,UnitPrice,Package,IsDiscontinued) values (2,'seafood',163.09,'32 - 1 kg pkgs',1)
insert into Product (Id,ProductName,UnitPrice,Package,IsDiscontinued) values (3,'chai',100.50,'10 boxes x 20 bags',1)
insert into Product (Id,ProductName,UnitPrice,Package,IsDiscontinued) values (4,'chocolate',148.53,'10 pkgs',0)
insert into Product (Id,ProductName,UnitPrice,Package,IsDiscontinued) values (5,'nutella',511.42,'15 - 625 g jars',1)

alter table Product
add Catagoryname nvarchar(30)
update Product
set Catagoryname = 'seafood'
where Id = 2
update Product
set Catagoryname = 'dessert'
where Id = 4
alter table Product
add Suppliers nvarchar(30)
update Product
set Suppliers = 'EXOTIC LIQUIDS'
where Id = 2
update Product
set Suppliers = 'Wipro Ltd'
where Id = 4

SELECT Product.Suppliers,Product.[UnitPrice] AS Totalprice ,Orders.[Shippingname] FROM Product
INNER JOIN Orders ON Orders.[ID]=Product.[Id]
WHERE  Product.Suppliers = 'EXOTIC LIQUIDS' AND Product.[UnitPrice] >50

select * from Product
 where Catagoryname = 'seafood'


SELECT Product.Id,Product.[ProductName] AS OrderPlaced ,OrderItem.[ID] FROM Product
INNER JOIN OrderItem ON OrderItem.[ID]=Product.[Id]
WHERE  Product.ProductName = 'chai' 

SELECT ProductName, UnitPrice 
FROM Product 
ORDER BY UnitPrice DESC;

SELECT ProductName, UnitPrice 
FROM Product 
ORDER BY UnitPrice ASC;

select ProductName, Catagoryname, Suppliers from Product where Suppliers <> 'NULL'

SELECT CONCAT(Customer.[FirstName],' ',Customer.[LastName]) AS [CUSTOMER-NAME],Orders.[OrderDate],OrderItem.[OrderId],Product.[ProductName] FROM Product
INNER JOIN OrderItem ON OrderItem.[OrderId]=Product.[ID]
INNER JOIN Orders ON Orders.[ID]=OrderItem.[OrderId]
INNER JOIN Customer ON Customer.[ID]=Orders.[ID]