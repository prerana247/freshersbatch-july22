use[Assignment]
go
create table Customer
(
ID int not null primary key,
FirstName nvarchar(40) not null,
LastName nvarchar(40),
City nvarchar(40),
Country nvarchar(40),
Phone nvarchar(20)
)
select * from Customer
insert into Customer (ID,FirstName,LastName,City,Country,Phone) values (1,'Anish','Dubey','Mumbai','India','123')
insert into Customer (ID,FirstName,LastName,City,Country,Phone) values (2,'Priya','Jain','France','Lyon','456')
insert into Customer (ID,FirstName,LastName,City,Country,Phone) values (3,'Sumit','Roy','Germany','Berlin','789')
insert into Customer (ID,FirstName,LastName,City,Country,Phone) values (4,'Ishita','Parekh','Canada','Tornto','000')
insert into Customer (ID,FirstName,LastName,City,Country,Phone) values (5,'abc','xyz','Canada','Tornto','000')
insert into Customer (ID,FirstName,LastName,City,Country,Phone) values (6,'def','efg','Canada','Tornto','000')

select * from Customer where Country like 'A%' or Country like 'I%'

select * from Customer where FirstName like '__i%'
SELECT * FROM Customer WHERE Country = 'Germany'
UPDATE Customer
SET Country = 'Germany', City= 'Berlin'
WHERE ID = 3
select * from Customer where FirstName like '_u%'

SELECT  FirstName,LastName, 
              FirstName + ' ' + LastName AS FullName
FROM Customer

alter table Customer
ALTER COLUMN FaxNumber nvarchar(40)
alter table Customer 

select * from Supplier
select * from Customer

SELECT Supplier.FaxNumber, Customer.FirstName
FROM Customer
INNER JOIN Supplier
ON Customer.ID=Supplier.ID;

ALTER table Customer
UPDATE Customer
SET Phone = '030-0074321'
WHERE ID = 4

select Customer.[Firstname],Customer.[Phone],Orders.[OrderNumber]
from Customer
inner join Orders
on Customer.ID=Orders.ID
where Phone = '030-0074321'

select Customer.[Firstname],Customer.[Phone],Customer.[City],Orders.[OrderNumber]
from Customer
inner join Orders
on Customer.ID=Orders.ID
where city <> 'london'

SELECT * FROM CUSTOMER WHERE SUBSTRING([FirstName],1,2)='RA'