use[Assignment]
go
CREATE TABLE Employee  
(  
EmployeeID int,  
FirstName nvarchar(40),  
LastName nvarchar(40),  
Manager nvarchar(40),  
Dept_name nvarchar(50),  
Rating nvarchar(5),  
DOJ datetime not null
)
insert into Employee (EmployeeID,FirstName,LastName,Manager,Dept_name,Rating,DOJ) values (1,'Riya','Soni','Mrs.Patel','HR','4','7-11-2019')
insert into Employee (EmployeeID,FirstName,LastName,Manager,Dept_name,Rating,DOJ) values (2,'Mike','Lopez','Mr Allen','ANALYST','2','3-12-2020')
insert into Employee (EmployeeID,FirstName,LastName,Manager,Dept_name,Rating,DOJ) values (3,'Blake','Martin','Mr Adams','SALES','5','8-11-2022')

select * from Employee
SELECT  FirstName,LastName, 
              FirstName + ' ' + LastName AS FullName
FROM Employee

SELECT  FirstName,LastName,Manager FROM Employee order by Manager

select FirstName, Dept_name, Rating from Employee

SELECT *
FROM Employee 
ORDER BY DOJ ASC;

SELECT *
FROM Employee 
ORDER BY DOJ DESC;